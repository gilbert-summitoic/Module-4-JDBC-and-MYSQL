/**
 * Module 4 Assignment
 * @ Gilbert Shombong
 */

import java.sql.*;
import java.util.Scanner;

public class ClassicModels {
    public static void main(String[] args) {
/**
 * Step 3: Number 4 - 7. Try-Catch to Close connection
  */
        try {   // Check for database connectivity and transactions error
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Use DriverManager in Connection class to connect to database with String credentials
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/classicmodels",
                    "root", "admin");
            Statement stmt = con.createStatement();
            //Retrieve ProductName "Classic Cars" from products table
            ResultSet rs = stmt.executeQuery(
                    "SELECT ProductName, productLine FROM products WHERE productLine = 'Classic Cars'" +
                            "LIMIT 5;");

            //use ResultsetMetaData to retrieve and print column name
            ResultSetMetaData rsMeta = stmt.getResultSet().getMetaData();
            System.out.printf("%1$-35s|\t",rsMeta.getColumnName(1));   //print productName name by index 1
            System.out.println(rsMeta.getColumnName(2)); //print column productLine by index 2 from database
            System.out.println("--------------------------------------------------------"); //prints new line
            //Use while Loop to iterate through Resultset
            while (rs.next()) {
                System.out.printf("%1$-35s|\t",rs.getString("productName")); //use printf to indent next string
                System.out.print(rs.getString("productLine")); //start print on column 35
                System.out.println();   // print each row in its own line.
            }

/**
 * Step 4: User input
 */
            System.out.println();   //free line for clarity
            //Request user input to see productLines for cars, ships or motorcycle
            Scanner input = new Scanner(System.in); //scanner to receive y/n

            //prompt user if interested to see more car models
            System.out.print("Would you like to see other Product Lines? y/n (default N): ");
            String userResponse = input.next(); //receives user input

            int count = 1;
            while (true&&count<2) {
                //first if block defaults to No and quits
                if (userResponse==null || userResponse.equalsIgnoreCase("n")) {
                    System.err.println("Thanks for your response. Come back for more...");
                    break;  //End in N is entered
                    //As interested, query and display models
                } else if (!(userResponse == null) && userResponse.equalsIgnoreCase("y")) {
                    //String[] models={"classic", "ship", "motorcycle"};

                    input = new Scanner(System.in); //create new Scanner to receive new input
                    System.out.print("Choose a model: planes | ships | motorcycles |" +
                            " trucks | buses | trains | vintage | classics:");
                    //Receive user's choice, generate query and return respond.
                    String choice = input.nextLine();
                    /**
                    String pattern = " ";
                    String[] chosen = choice.split(pattern); */
                    //pass user's choice to query
                    rs = stmt.executeQuery("SELECT productName, productLine FROM products " +
                            "WHERE productLine LIKE'%" + choice + "%' " +
                            "ORDER BY productLine ASC LIMIT 10");
                    System.out.println("--------------------------------------------------------"); //prints new line
                    System.out.printf("%1$-35s|\t",rsMeta.getColumnName(1));   //print productName name by index 1
                    System.out.println(rsMeta.getColumnName(2)); //print column productLine by index 2 from database
                    System.out.println("--------------------------------------------------------"); //prints new line
                }else {
                    System.out.println("invalid choice entered");
                }//end else

                    while (rs.next()){
                        System.out.printf("%1$-35s|\t",rs.getString("productName")); //use printf to indent next string
                        System.out.print(rs.getString("productLine")); //start print on column 35
                        System.out.println();   // print each row in its own line.
                    }//end while loop with user's choice
                System.out.println();   //prints new empty line for clarity
                count++; //increment while loop count

                } //End Main else-if

/**
 * Step 5: Insert and Update record
 */     //update USS Monitor record
        stmt.executeUpdate("INSERT INTO PRODUCTS " +
                "(productCode, productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP)" +
                "VALUES " +
                "(\"S72_3213\",\"USS Monitor\", \"Ships\", \"1:72\", \"Second Gear Diecast\", \"Ironclad warship with her steam engine and revolving turret\", 780, 35.00, 55.00);");

/**        //retrieve USS Monitor updated record
*/        rs = stmt.executeQuery("SELECT productCode, productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP " +
                "FROM products WHERE productName = \"USS Monitor\";");
        int columns = rsMeta.getColumnCount();
            System.out.println("\n======================Record inserted Below===============================");
            //use while loop to retrieve query
            while (rs.next()) {
                for (int i = 1; i <= columns; i++) { //loop to display retrieved records from query
                    System.out.printf("|\t%1$-15s", rs.getString(i)," "," "); //format output display before each field-record
                }
                System.out.printf("\t%s|", ""); //format output display after each field-record
                System.out.println(); //display complete field-records in a new line
            } //End while loop
            System.out.println("\n\n");

 /**
 * Step 6: Delete record before step 5 to prevent duplication
 */
            stmt.executeUpdate("DELETE FROM products WHERE productName='USS Monitor'");

/** Display new results to ensure record is deleted
*/          rs = stmt.executeQuery("SELECT productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP " +
                    "FROM products;");
            columns = rsMeta.getColumnCount();
            //use while loop to retrieve query

            System.out.println("=====================Full Query after is deleted===========================");
            while (rs.next()) {
                for (int i = 1; i <= columns; i++) { //loop to display retrieved records from query
                    System.out.printf("|\t%1$-35s", rs.getString(i)," "," "); //format output display before each field-record
                }
                System.out.printf("\t%s|", ""); //format output display after each field-record
                System.out.println(); //display complete field-records in a new line
            } //End while loop
            con.close();//close connection to the database
        }catch (Exception e) {
            e.printStackTrace();
        }//End Try-catch
    } //End main method
}// End ClassicModels class
